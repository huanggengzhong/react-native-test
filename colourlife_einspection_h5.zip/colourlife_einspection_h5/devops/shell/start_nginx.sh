cp vhost.conf /etc/nginx/conf.d/
/usr/sbin/nginx
/usr/sbin/nginx -s reload
