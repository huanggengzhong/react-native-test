#!/bin/bash
sh start_nginx.sh
tail -f /dev/null
