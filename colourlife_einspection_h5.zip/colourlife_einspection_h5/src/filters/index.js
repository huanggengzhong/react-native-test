// doc https://cn.vuejs.org/v2/guide/filters.html
export * from "./toFixed";
