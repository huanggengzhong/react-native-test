import axios from 'axios'
import qs from 'qs';

// let base = '';
let base = 'https://api-exunjiantest.colourlife.com';
let url = document.domain;

if (url === "exunjian.colourlife.com") { //正式

    base = document.location.protocol + '//api-exunjian.colourlife.com';

} else if (url === "exunjianbeta.colourlife.com") { //预发

    base = document.location.protocol + '//api-exunjianbeta.colourlife.com';

} else if (url === "exunjiantest.colourlife.com") { //测试
    base = document.location.protocol + '//api-exunjiantest.colourlife.com';
}

/**
 * 创建请求
 * @param {string} URL 请求地址
 */
export function createdFormDataAxios(URL, params) {
    let formData = new FormData();
    for (var variable in params) {
        if (params.hasOwnProperty(variable)) {
            formData.append(variable, params[variable]);
        }
    }
    return axios.post(base + URL, formData, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
        // withCredentials: true,
    });
}

axios.interceptors.request.use(

    config => {

        // let token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBfaWQiOiJJQ0VFWEowLUVIMzYtWjRQNS02VDZMLUI5VkxPUEo4VE5CVSIsImp0aSI6ImYyMmFmMmI1MTQ0Mzk1YTc0NDViMzY1NGU5NTIwZjlmIiwiaWF0IjoxNTY4MjU3Mzk4LCJuYmYiOjE1NjgyNTczOTgsImV4cCI6MTU2ODI2NDU5OCwic3ViIjoicTl1aHphZklsWjQ9Iiwic3ViX3V1aWQiOiJsTXVieDVXYVpHbU9hSitYYTJKb21HMmNZRzZTazI1ZmJaT2FsSlBEWnBPWW4yNlciLCJzY29wZXMiOiIlNUIlNUQifQ==.bf41f46bd20e7ea110570721cdac6e99f4712c097a062b777618e2072c23744b";
        // // let token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBfaWQiOiJJQ0VFWEowLUVIMzYtWjRQNS02VDZMLUI5VkxPUEo4VE5CVSIsImp0aSI6IjNkMzk1NTI4YTE4YTA5ZmVjMGQwMzNiODQ5OGJjNzEzIiwiaWF0IjoxNTY4MDIxNDM4LCJuYmYiOjE1NjgwMjE0MzgsImV4cCI6MTU2ODAyODYzOCwic3ViIjoibTh1dTA2ZlBtYVBJIiwic3ViX3V1aWQiOiJiSmlibFdyRmFXV09uSnBwbW1Kb21XYVZZSmZHbEpoZmE4YWVtWk9hYkpocG0yZkciLCJzY29wZXMiOiIlNUIlNUQifQ==.d601a0a1ebbefcd86999dfc9f311af4bc8cd1b07b0e03b6168d21652c6cf2f3e';
        // if (token) {
        //     config.headers.token = token;
        // }

        return config;

    },
    function(error) {
        return Promise.reject(error);

    }
)

export default base
/**
 * 接单页
 * @param {object} params
 * @param {string} params.access_token 用户鉴权token
 * @param {object} params.orderno 人力资源订单号
 */
export const getOrderPage = (params) => {
    // return get('api/h5/checkOrder/detail', { params });
    return axios.get(`${base}/api/h5/order/detail`, { params: params }).then(res => res.data)
};

/**
 * 接单or取消接单
 * @param {string} params.task_id 任务编号
 * @param {string} params.status 订单状态 1：取消订单 2接单
 */
export function getOrCancel(params) {
    // return instance.post('api/h5/check/in/sign', params);
    return axios.post(`${base}/api/h5/modify/order/status`, qs.stringify(params)).then(res => res.data)
}

/**
 * 巡查订单任务列表列表
 * @param {object} params
 * @param {string} params.access_token 用户鉴权token
 * @param {object} params.order_no 巡检订单编号
 */
export const getOrder = (params) => {
    // return get('api/h5/checkOrder/detail', { params });
    return axios.get(`${base}/api/h5/checkOrder/detail`, { params: params }).then(res => res.data)
};
/**
 * 巡查订单任务详情
 * @param {object} params
 * @param {string} params.access_token 用户鉴权token
 * @param {object} params.task_id 任务编号
 */
export const getOrderDetail = (params) => {
    // return get('api/h5/checkOrder/detail', { params });
    return axios.get(`${base}/api/h5/checkTask/detail`, { params: params }).then(res => res.data)
};

/**
 * 上传照片
 * @param {object} params
 * @param {string} params.access_token 用户鉴权token
 * @param {file} params.file 文件图片
 */
export function upload(params) {
    return createdFormDataAxios('/api/h5/image/upload', params);
    // return axios.post(`${base}/api/h5/image/upload`, qs.stringify(params)).then(res => res.data)
}

/**
 * 下一步操作记录地理位置照片
 * @param {string} params.access_token 用户鉴权token
 * @param {string} params.file_url 文件图片地址
 * @param {string} params.task_id 任务编号
 * @param {string} params.order_no 订单号
 */
export function nextGeographicLocation(params) {
    // return instance.post('api/h5/check/in/sign', params);
    return axios.post(`${base}/api/h5/check/in/sign`, qs.stringify(params)).then(res => res.data)
}

/**
 * 提交单个任务巡检
 * @param {string} params.access_token 用户鉴权token
 * @param {string} params.task_id 任务编号
 * @param {string} params.task_content 巡检内容
 */
export function postPatrolOrder(params) {
    // return instance.post('api/h5/checkTask/submit', params);
    return axios.post(`${base}/api/h5/checkTask/submit`, qs.stringify(params)).then(res => res.data)
}

/**
 * 结束巡查订单
 * @param {string} params.access_token 用户鉴权token
 * @param {string} params.order_no 订单号
 */
export function endOrder(params) {
    // return instance.post('api/h5/checkOrder/submit', params);
    return axios.post(`${base}/api/h5/checkOrder/submit`, qs.stringify(params)).then(res => res.data)
}