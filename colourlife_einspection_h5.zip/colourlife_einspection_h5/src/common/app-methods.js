/*
 * @Author: WangQiBiao
 * @LastEditors: WangQiBiao
 * @Description: 原生方法
 * @Date: 2019-03-21 20:00:52
 * @LastEditTime: 2019-03-28 21:16:00
 */
function ios(methodsName, ...args) {
    return new Promise((resolve, reject) => {
        try {
            setupWebViewJavascriptBridge(function(bridge) {
                bridge.callHandler(methodsName, ...args, resolve)
            })
        } catch (error) {
            reject(error)
        }
    })
}

function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
        return callback(window.WebViewJavascriptBridge)
    }
    if (window.WVJBCallbacks) {
        return window.WVJBCallbacks.push(callback)
    }
    window.WVJBCallbacks = [callback]
    var WVJBIframe = document.createElement('iframe')
    WVJBIframe.style.display = 'none'
    WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__'
    document.documentElement.appendChild(WVJBIframe)
    setTimeout(function() {
        document.documentElement.removeChild(WVJBIframe)
    }, 0)
}

function android(methodsName, ...args) {
    return new Promise((resolve, reject) => {
        try {
            if (args.length) {
                resolve(JSON.parse(window.jsObject[methodsName](...args)))
                return
            }
            resolve(JSON.parse(window.jsObject[methodsName]()))
        } catch (error) {
            reject(error)
        }
    })
}
export const isIos = /(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)
const App = (function() {
    // if (process.env.NODE_ENV === 'production') {
    //   return isIos ? ios : android
    // } else {
    //   return () => {}
    // }
    return isIos ? ios : android
})()

export default {
    /**
     * 获取定位信息
     * @typedef LocationRes
     * @property {string} LocationRes.longitude 经度
     * @property {string} LocationRes.latitude 纬度
     * @property {string} LocationRes.province 省
     * @property {string} LocationRes.city 市
     * @property {string} LocationRes.district 区
     * @property {string} LocationRes.address 详细地址
     * @returns {LocationRes}
     */
    getLocationActivity() {
        return App('getLocationActivity')
    },
    dataURItoBlob(dataurl, filename) {
        //dataurl是base64格式
        //  console.log(dataurl)
        var arr = dataurl.split(","),
            mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]),
            n = bstr.length,
            u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        console.log('ds')
        return new File([u8arr], filename, { type: mime });
        // return new Blob([u8arr], { type: mime });
    },
    /**拍照
     * @param {Function} callback ({ imagepath,size,type,name })=>void
     * @return {*|Promise<any>}
     */
    galleryActivity() {
        window.galleryActivityHandler = info => {

            callback(JSON.parse(info))
        }
        return App('galleryActivity', JSON.stringify({ "choiceMode": 1, "photoType": "imagepath" }))
    },
    /**
     * 调起通用支付
     * @param {string} sn
     * @param {string} returnUrl
     */
    payFromHtml(sn, returnUrl) {
        if (isIos) {
            return loadURL(sn, returnUrl)
        }

        function loadURL(sn, returnUrl) {
            let url = `*payFromHtml5*${sn}*${returnUrl}`
            let iFrame = document.createElement('iframe')
            iFrame.setAttribute('src', url)
            iFrame.setAttribute('style', 'display:none;')
            iFrame.setAttribute('height', '0px')
            iFrame.setAttribute('width', '0px')
            iFrame.setAttribute('frameborder', '0')
            document.body.appendChild(iFrame)
            iFrame.parentNode.removeChild(iFrame)
            iFrame = null
        }
        return App('payFromHtml', sn, returnUrl)
    }
}