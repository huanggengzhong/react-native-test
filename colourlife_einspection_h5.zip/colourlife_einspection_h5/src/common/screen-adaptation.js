function resetFontSize() {
    var windowW = document.documentElement.clientWidth
    var scale = windowW / 375
    var newSize = 100 * scale
    document.getElementsByTagName('html')[0].style.fontSize = newSize + 'px'
}
window.addEventListener('resize', function() {
    resetFontSize()
}, false)

resetFontSize()