<template>
  <div id="app">
    <transition name="fade" mode="out-in">
      <router-view/>
    </transition>
  </div>
</template>

<script>
import {getLocation} from '@/common/utils';
// import { Toast } from 'vant';
export default {
  name: 'app',
  mounted() {
    getLocation()
  },

  methods:{
  

  }

};
</script>
<style lang="scss" scoped>
#app {
  margin: auto;
  min-height: 100%;
  width: 100%;
  background: #f1f1f1;
}
</style>
