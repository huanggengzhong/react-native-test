import Vue from 'vue'
import Router from 'vue-router'
import Home from '../views/home/index.vue'
import Sign from '../views/sign/index.vue'
import Detail from '../views/detail/index.vue'
import DetailForm from '../views/detail/indexfrom.vue'
import Receiving from '../views/receiving/index.vue'
import Erro from '../views/404/index.vue'
Vue.use(Router)

export default new Router({
    // mode: 'history',
    // base: process.env.BASE_URL,
    routes: [{
            path: '/',
            name: 'receiving',
            component: Receiving
        },
        {
            path: '/home',
            name: 'home',
            component: Home
        },
        {
            path: '/sign',
            name: 'sign',
            component: Sign
        },
        {
            path: '/detail',
            name: 'detail',
            component: Detail
        },
        {
            path: '/detailcal',
            name: 'detailcal',
            component: DetailForm
        },
        {
            path: '/404',
            name: '404',
            component: Erro
        }
    ]
})