<template>
  <div class="empty">
      <div class="empty_index_img">
        <img src="./img@2x.png" alt="empty_index">
      </div>
     <p>网络无法连接，请刷新重试</p>
     <button @click="load">刷新一下</button>
  </div>
</template>
<script>
import {getOrderDetail,postPatrolOrder} from '@/api';
import Vue from 'vue';
import { Notify,Toast  } from 'vant';
import VueClipboard from 'vue-clipboard2';
Vue.use(VueClipboard);
Vue.use(Notify).use(Toast);
export default {
  data () {
    return {
    
    };
  },
  created () {
    // this.getOrderDetail();
  },
  mounted(){//这里必须是mouted钩子
  
  },
  methods: {
    load(){
      location.reload()
    }
  }
};
</script>
<style lang="scss" scoped>
.empty {
  position: relative;
    height: 100vh;
  background: #fff;
  box-sizing: border-box;
  .empty_index_img{
    width: 1.4rem;
    height: 1rem;
    position: absolute;
    top: 2.07rem;
    left: 50%;
    margin-left: -0.7rem;
  }
  img{
   width: 100%;
   height: 100%;
  }
  p{
    font-family: PingFangTC-Regular;
    width: 100%;
    font-size: 0.16rem;
    color: #999FAA;
    letter-spacing: 0.0112rem;
    text-align: center;
    position: absolute;
    top: 3.16rem;
  }
  button{
    width: 1.6rem;
    height: 0.44rem;
    color:#1DA1F4;
    background: #fff;
    border: 1px solid #1DA1F4;
    border-radius: 4px;
    text-align: center;
    line-height: 0.44rem;
    position: absolute;
    top: 3.79rem;
    left: 50%;
    margin-left: -0.8rem;
  }
  }

</style>
