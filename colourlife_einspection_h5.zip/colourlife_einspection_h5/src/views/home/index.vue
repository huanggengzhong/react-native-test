<template>
<div>
  <div class="home">
    <div class="top">
      <span class="tip"></span>
      <span class="title">巡检订单</span>
    </div>
    <div>
      <ul>
        <li v-for="(item,index) in orderList" :key="index">
           <template v-if="item.status == 0">
            <router-link :to="{path:'/sign',query:{id: item.id,name: getName,orderId:item.order_no}}" tag="span">
              <p class="order_title">{{index+1}}.{{item.inspection_name}}</p>
              <p class="place clearfix">
                <span>位置信息：</span>
                <span class="text">{{item.community_position}}</span>
                <img src="./images/icon_tz@2x.png" alt="">
              </p>
              <p class="status">
                <span>任务状态：</span>
                <span v-if="item.status == 0">未检查</span>
                <span v-else-if="item.status == 1">已检查</span>
                <!-- <span>未检查</span> -->
              </p>
            </router-link>
           </template>
           <template v-else-if="item.status == 1">
              <router-link :to="{path:'/detailcal',query:{id: item.id}}" tag="span">
                <p class="order_title">{{index+1}}.{{item.inspection_name}}</p>
                <p class="place clearfix">
                  <span>任务状态：</span>
                  <span class="text">已完成</span>
                  <img src="./images/icon_tz@2x.png" alt="">
                </p>
                <p class="place clearfix">
                  <span>完成时间：</span>
                  <span class="text">{{item.finish_time}}</span>
                  <!-- <img src="./images/icon_tz@2x.png" alt=""> -->
                </p>
                </router-link>
           </template>
        </li>
         <!-- <li>
          <p class="order_title">1.#电梯</p>
          <p class="place clearfix">
            <span>位置信息：</span>
            <span class="text">广东省深圳市龙华新区民治街道七星商业广场</span>
            <img src="./images/icon_tz@2x.png" alt="">
          </p>
          <p class="status">
            <span>任务状态：</span>
            <span>未检查</span>
          </p>
        </li> -->
       
      </ul>
    </div>
    
  </div>
 <button class="btn" @click="endServer" :class="{ active: !endBol }" :disabled='endBol' >结束服务</button>
 </div>
</template>
<script>
import Vue from 'vue';
import { Toast } from 'vant';
import {getOrder, getPjProjectByUserId, getIndexOrderList, endOrder} from '@/api';
Vue.use(Toast);
export default {
  data () {
    return {
      address: '',
      loading: false,
      endBol: true,//是否能结束服务
      orderList: [],
      getName:'',
    };
  },
  components: {
    // Statement,
    // AddressSelected,
    // OrderItem
  },
  created () {
    this.getOrder();
    this.getName = this.$route.query.name
  },
  methods: {
    getOrder () {
      getOrder({order_no: this.$route.query.id}).then(res => {
        console.log(res)
        if(res.code === 0 && res.content.code === 0){
            let data = res.content.content
            if(data.length > 0){
              this.orderList = data
              let arr = []
              data.map(item=>{
                arr.push(item.status)
              })
              // console.log(arr)
              if(arr.indexOf(0) === -1){
                this.endBol = false;
              }
            }
        }else{
            Toast.fail( res.message || '任务获取失败');
        }
      });
    },
    // this.$route.query.id
    endServer(){
      let params = {
        order_no: this.$route.query.id,
        oa_account: sessionStorage.getItem('oa_account') || '',//发单人
        humanTraNo: sessionStorage.getItem('humanTraNo') || '',//人资单号
        longitude: sessionStorage.getItem('longitude') || '',//作业地点经度
        latitude: sessionStorage.getItem('latitude') || '',//作业地点纬度
        address: sessionStorage.getItem('address') || '',//作业地点
      }
      endOrder(params).then(res=>{
        if(res.code == 0){
          this.$router.push({
            path: "/",
            query: {
              humanTraNo: sessionStorage.getItem('humanTraNo') || '',
            }
          });
        }else{
          Toast.fail( res.message || '结束服务失败');
        }
          
      })
    }
    // switchs () {
    //   this.addressInfo.isShow = true;
    // },
    // async getPjProjectByUserId () {
    //   await getPjProjectByUserId({userid: window.PLATFORM_CONFIG.userInfo.userid}).then(res => {
    //     if (res.data) {
    //       this.addressInfo.lists = res.data;
    //       // 存在已选中的小区，取当前存储已选中的小区，否则默认显示第一条
    //       let irow = JSON.parse(localStorage.getItem('addressInfo')) || res.data[0];
    //       this.address = `${irow.pj_name} -> ${irow.deptname} -> ${irow.deptParentname}`;
    //       this.orderParams.pj_id = irow.pj_id;
    //       this.getStatisticalInfo(irow.pj_id);
    //       this.getIndexOrderList();
    //     }
    //   });
    // },
    // changeAddress (item) {
    //   if (!item.pj_id) {
    //     return;
    //   }
    //   this.orderParams.pj_id = item.pj_id;
    //   this.address = `${item.pj_name} -> ${item.deptname} -> ${item.deptParentname}`;
    //   localStorage.setItem('addressInfo',JSON.stringify(item));
    //   this.getStatisticalInfo(item.pj_id);
    //   this.orderList = [];
    //   this.getIndexOrderList();
    // },
    // getIndexOrderList () {
    //   getIndexOrderList(this.orderParams).then(res => {
    //     this.loading = false;
    //     if (res.data.lastPage) {
    //       this.finished = true;
    //     }
    //     this.orderList = [...this.orderList, ...res.data.list];
    //   });
    // },
    // onLoad () {
    //   if (this.orderParams.pj_id) {
    //     this.loading = true;
    //     this.orderParams.pageNumber++;
    //     this.getIndexOrderList();
    //   }
    // }
  }
};
</script>
<style lang="scss" scoped>
// @import './style.scss';
.btn{
      position: fixed;
      bottom: 0;
      width: 100%;
      height: 0.44rem;
      background: #D4D9DC;
      border: none;
      text-align: center;
      line-height: 0.44rem;
      font-family: PingFangTC-Regular;
      font-size: 0.16rem;
      color: #FFFFFF;
      letter-spacing: 0.0112rem;
    }
.active{
  background: #1DA1F4;
}
.home {
    overflow: hidden;
    height: 100%;
    padding: 0 0.15rem 0.44rem;
    
    .top{
      .tip{
        display: inline-block;
        width:0.04rem;
        height: 0.15rem;
        margin-right: 0.05rem;
        background: #1DA1F4;
      }
      margin: 0.16rem 0 0.12rem;
      font-family: PingFangTC-Medium;
      font-size: 0.16rem;
      color: #333B46;
      letter-spacing: 0.0112rem;
    }
    ul li{
      background: #FFFFFF;
      border-radius: 0.04rem;
      padding: 0 0.11rem 0.13rem 0.1rem;
      margin-bottom: 0.15rem;
      .order_title{
        font-family: PingFangTC-Regular;
        font-size: 0.16rem;
        color: #333B46;
        letter-spacing: 0.0112rem;
        padding-top: 0.09rem
      }
      .place{
        // width:2.88rem;
        // padding-right: 0.27rem;
        // background: url(./images/icon_tz@2x.png) no-repeat center right;
      // background-size: 0.16rem 0.16rem;
       img{
         width: 0.16rem;
         height: 0.16rem;
         margin-left: 0.19rem;
       }
        span:first-child{
          font-family: PingFangTC-Regular;
          float: left;
          // font-size: 14px;
          color:  #999FAA;
          letter-spacing: 0.0114rem;
        }
        .text{
          display: inline-block;
          float: left;
          width: 2.13rem;
          font-family: PingFangTC-Regular;
          // font-size: 14px;
          color: #626B77;
          letter-spacing: 0.0114px;
          line-height: 0.2rem;
        }
      }
      .status{
        // margin-bottom: 0.13rem;
         span:first-child{
          font-family: PingFangTC-Regular;
          // font-size: 14px;
          color:  #999FAA;
          letter-spacing: 0.0114rem;
        }
        span:last-child{
          font-family: PingFangTC-Regular;
          // font-size: 14px;
          color: red;
          letter-spacing: 0.0114px;
          line-height: 0.2rem;
        }
      }
    }
}
</style>
