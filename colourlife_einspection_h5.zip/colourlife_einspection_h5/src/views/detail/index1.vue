<template>
  <div class="detail">
    <div class="top">
         <p class="order_title">{{orderDetail.task}}</p>
          <p class="place clearfix">
            <span>设备编号：</span>
            <span class="text">{{orderDetail.id}}</span>
          </p>
          <p class="status">
            <span>巡检方案：</span>
            <span>{{orderDetail.inspection_name}}</span>
          </p>
    </div>
    <div class="tops">
      <span class="tip"></span>
      <span class="titles">巡检订单</span>
    </div>
    <div class="option">
      <ul>
        <li v-for="(item,index) in check" :key="index">
          <p class="li_title">{{index+1}}.{{item.question}}</p>
          <van-radio-group @change="changeVal" class="quest"  v-if="item.has_fill == 1" >
            <van-radio v-for="(itemSon,indexSon) in item.anwser_list" :key="indexSon" class="check" :name="'radio'+item.key+indexSon" checked-color="#1DA1F4" icon-size="0.12rem">
              <template v-if="itemSon !== '其它____'">
                    <span>{{itemSon}}</span>
              </template>
              <template v-else>
                  <p>其它</p>
                  <textarea :name="'other'+item.key" id="" cols="5" rows="5"></textarea>
              </template>
           </van-radio>
            <van-radio  class="check" name="2" checked-color="#1DA1F4" icon-size="0.12rem">
               <p>其它</p>
                  <textarea :name="'other'+item.key" id="" cols="5" rows="5"></textarea>
            </van-radio>
          </van-radio-group>
           <van-checkbox-group class="quest" v-else-if="item.has_fill == 2"  v-model="result">
              <van-checkbox
               v-for="(itemSon,indexSon) in item.anwser_list"
                :key="indexSon"
                :name="'checkbox'+item.key+indexSon"
                class="check"
                @change="changeVal"
                checked-color="#1DA1F4"
                icon-size="0.12rem"
                shape="square"
              >
              <template v-if="itemSon !== '其它____'">
                    <span>{{itemSon}}</span>
              </template>
              <template v-else>
                  <p>其它</p>
                  <textarea :name="'other'+item.key" id="" cols="5" rows="5"></textarea>
              </template>
              </van-checkbox>
            </van-checkbox-group>
          <div class="quest" v-else-if="item.has_fill == 3">
            <div class="check1" v-for="(itemSon,indexSon) in item.anwser_list" :key="indexSon">
              <span>{{itemSon}}：</span>
              <input :name="'text'+item.key+indexSon" class="line" type="text">
            </div>
          </div>
        </li>
        <!-- <li>
          <p class="li_title">1.电梯是否运行平稳</p>
          <van-checkbox-group v-model="result">
              <van-checkbox
                v-for="(item, index) in list"
                :key="item"
                :name="item"
                class="check"
                checked-color="#1DA1F4"
                icon-size="0.12rem"
                shape="square"
              >
                复选框 {{ item }}
              </van-checkbox>
            </van-checkbox-group>
        </li>
        <li>
          <p class="li_title">1.电梯是否运行平稳</p>
          <div>
            <div class="check">
              <span>是否：</span>
              <input class="line" type="text">
            </div>
            <div class="check">
              <span>是否：</span>
              <input class="line" type="text">
            </div>
          </div>
        </li> -->
      </ul>
    </div>
    <button class="btn" @click="postPatrolOrder">提交</button>
  </div>
</template>
<script>
import {getOrderDetail,postPatrolOrder} from '@/api';
import Vue from 'vue';
import { RadioGroup, Radio,Checkbox, CheckboxGroup,Field} from 'vant';
Vue.use(Checkbox).use(CheckboxGroup);
Vue.use(RadioGroup).use(Radio).use(Field);
export default {
  data () {
    return {
      address: '',
      loading: false,
      finished: false,
      orderDetail: '',
      check: [],
      show: false,
      fileObj: '',
      radio: '',
      list: ['a', 'b', 'c'],
      result: ['a', 'b']
    };
  },
  components: {
    // Statement,
    // AddressSelected,
    // OrderItem
  },
  created () {
    this.getOrderDetail();
  },
  methods: {
    // ,order_no:"201909121242565321449424"
    changeVal(e){
      console.log(e)
    },
    getOrderDetail () {
      getOrderDetail({task_id: this.$route.query.id}).then(res => {
        console.log(res)
        if(res.code === 0 && res.content.code === 0){
            let data = res.content.content
            if(data.length > 0){
              this.check = JSON.parse(data[0].inspection_comment) 
              console.log(this.check)
              this.orderDetail = data[0]
            }
        }else{
            // Toast.fail( res.message || '任务获取失败');
        }
      });
    },
    postPatrolOrder(){
      this.check.map(item=>{
        console.log(item)
        let anwser = []
        item.anwser_list.map(items=>{
          console.log(items)
          anwser.push(items)
        })
        item.anwser = anwser;
      })
      console.log(this.check)
      postPatrolOrder({task_id:this.$route.query.id,task_content: JSON.stringify(this.check)}).then(res=>{
          console.log(res)
      })
    }
  }
};
</script>
<style lang="scss" scoped>
// @import './style.scss';
    .detail{
      padding: 0.15rem 0 0.44rem;
      .option,.tops{
        padding: 0 0.15rem
      }
      .btn{
          position: fixed;
          bottom: 0;
          width: 100%;
          height: 0.44rem;
          background: #D4D9DC;
          border: none;
          text-align: center;
          line-height: 0.44rem;
          font-family: PingFangTC-Regular;
          font-size: 0.16rem;
          color: #FFFFFF;
          letter-spacing: 0.0112rem;
        }
        .top{
          margin: 0 0.15rem;
          background: #fff;
          padding: 0.1rem;
          border-radius: 0.04rem;
          .order_title{
            font-family: PingFangTC-Regular;
            font-size: 0.16rem;
            color: #333B46;
            letter-spacing: 0.0112rem;
          }
        .place{
          margin-top:0.08rem;
        }
        .status{
          margin-top:0.03rem;
        }
        .status,.place{
        // margin-bottom: 0.13rem;
         span:first-child{
          font-family: PingFangTC-Regular;
          // font-size: 14px;
          color:  #999FAA;
          letter-spacing: 0.0114rem;
        }
        span:last-child{
          font-family: PingFangTC-Regular;
          // font-size: 14px;
          color: #626B77;
          letter-spacing: 0.0114px;
          line-height: 0.2rem;
        }
      }
        }
    .tops{
      .tip{
        display: inline-block;
        width:0.04rem;
        height: 0.15rem;
        margin-right: 0.05rem;
        background: #1DA1F4;
      }
      margin: 0.16rem 0 0.12rem;
      font-family: PingFangTC-Medium;
      font-size: 0.16rem;
      color: #333B46;
      letter-spacing: 0.0112rem;
    }
    .option{
      li{
        background: #FFFFFF;
        border-radius: 0.04rem;
        padding: 0.1rem;
        margin-bottom: 0.15rem;
        .quest{
          padding-left: 0.1rem;
        }
        .li_title{
          font-family: PingFangTC-Regular;
          font-size: 0.16rem;
          color: #333B46;
          letter-spacing: 0.0112rem;
        }
        .check{
          margin-top:0.08rem;
          font-family: PingFangTC-Regular;
          font-size: 0.14rem;
          color: #626B77;
          letter-spacing: 0.0114rem;
          position: relative;
           /deep/ .van-radio__icon{
               position: absolute;
               top: 0.05rem;
            }
           /deep/ .van-radio__label {
              margin-left: 0.2rem;
          }
        }
        .check1{
          display: flex;
           margin-top:0.08rem;
          font-family: PingFangTC-Regular;
          font-size: 0.14rem;
          color: #626B77;
          letter-spacing: 0.0114rem;
          span{
            display: inline-block;
            width: auto;
            flex: none;
          }
          input{
            border: none;
            border-bottom: 0.5px solid #D4D9DC;
            width: 100%;
            box-sizing: border-box;
          }
        }
        textarea{
          width: 2.9rem;
          height: 0.4rem;
          margin-top: 0.07rem;
        }
        .line{
          border: none; 
          border-bottom: 0.5px solid #D4D9DC;
          width: auto;
        }
      }
     
    }
    }
   
    
 
</style>
