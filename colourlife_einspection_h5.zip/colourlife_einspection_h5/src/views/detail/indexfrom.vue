<template>
  <div class="detail">
    <div class="top">
         <p class="order_title">{{orderDetail.task}}</p>
          <p class="place clearfix">
            <span>设备编号：</span>
            <span class="text">{{orderDetail.id}}</span>
          </p>
          <p class="status">
            <span>巡检方案：</span>
            <span>{{orderDetail.inspection_name}}</span>
          </p>
    </div>
    <div class="tops">
      <span class="tip"></span>
      <span class="titles">巡检订单</span>
    </div>
    <div class="option">
      <ul>
        <li v-for="(item,index) in check"  :key="index">
          <p class="li_title">{{index+1}}.{{item.question}}</p>

          <van-radio-group  v-model="list[item.key-1]" class="quest"  v-if="item.has_fill == 1" >
            <van-radio 
        
            v-for="(itemSon,indexSon) in item.anwser_list" 
            :key="indexSon" 
            class="check" 
            :class="'radio'+item.key+(indexSon+1)"
            :name="itemSon" 
            disabled
            checked-color="#1DA1F4" icon-size="0.12rem">
              <template v-if="itemSon !== '其他____'">
                    <span>{{itemSon}}</span>
              </template>
              <template v-else>
                  <p class="one">其他</p>
                  <textarea disabled  v-model="other[item.key-1]" :name="'other'+item.key" id="" ></textarea>
              </template>
           </van-radio>
          </van-radio-group>

           <van-checkbox-group v-model="list[item.key-1]" class="quest" v-else-if="item.has_fill == 2"  >
              <van-checkbox
              disabled
               v-for="(itemSon,indexSon) in item.anwser_list"
                :key="indexSon"
                :name="itemSon"
                class="check"
                :class="'checkbox'+item.key+(indexSon+1)"
            
                checked-color="#1DA1F4"
                icon-size="0.12rem"
                shape="square"
              >
              <template v-if="itemSon !== '其他____'">
                    <span>{{itemSon}}</span>
              </template>
              <template v-else>
                  <p class="one">其他</p>
                  <textarea disabled  v-model="other[item.key-1]" :name="'other'+item.key" id="" ></textarea>
              </template>
              </van-checkbox>
            </van-checkbox-group>

          <div class="quest" v-else-if="item.has_fill == 3">
            <div class="check1" v-for="(itemSon,indexSon) in item.anwser_list" :key="indexSon">
              <span v-if="itemSon == '其他____'">其他：</span>
              <span v-else>{{itemSon}}：</span>
              <input disabled :name="'text'+item.key+indexSon" v-model="list[item.key-1][indexSon]" class="line" type="text">
            </div>
          </div>
        </li>
      </ul>
    </div>
    <!-- <button class="btn" :class="{ active: !ispostbol }" :disabled="ispostbol" @click="postPatrolOrder">提交</button> -->
  </div>
</template>
<script>
import {getOrderDetail,postPatrolOrder} from '@/api';
import Vue from 'vue';
import { RadioGroup, Radio,Checkbox, CheckboxGroup,Field,Toast} from 'vant';
Vue.use(Checkbox).use(CheckboxGroup);
Vue.use(RadioGroup).use(Radio).use(Field).use(Toast);
export default {
  data () {
    return {
      address: '',
      ispostbol: true,
      orderDetail: '',
      check: [],
      show: false,
      fileObj: '',
      radio: '',
      list: [],
      other: [],
      result: []
    };
  },
  components: {
    // Statement,
    // AddressSelected,
    // OrderItem
  },
  created () {
    this.getOrderDetail();
  },
  methods: {
  
    getOrderDetail () {
      getOrderDetail({task_id: this.$route.query.id}).then(res => {
        console.log(res)
        if(res.code === 0 && res.content.code === 0){
            let data = res.content.content
            if(data.length > 0){
              this.check = JSON.parse(data[0].inspection_comment) 
              let anser = JSON.parse(data[0].inspection_result) 
              this.list = anser[anser.length-2]
              this.other = anser[anser.length-1]
              this.orderDetail = data[0]
            }
        }else{
            Toast.fail( res.message || '详情获取失败');
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
// @import './style.scss';
textarea:disabled,input:disabled{
  background: #fff;
}
// /deep/ .van-radio__icon--disabled .van-icon {
//         background-color: #1989fa;
//     border-color: #1989fa;
// }
/deep/ .van-radio__label--disabled,/deep/ .van-checkbox__label--disabled {
   color: #626B77; 
}
    .detail{
      padding: 0.15rem 0 0.44rem;
      .option,.tops{
        padding: 0 0.15rem
      }
      .btn{
          position: fixed;
          bottom: 0;
          width: 100%;
          height: 0.44rem;
          background: #D4D9DC;
          border: none;
          text-align: center;
          line-height: 0.44rem;
          font-family: PingFangTC-Regular;
          font-size: 0.16rem;
          color: #FFFFFF;
          letter-spacing: 0.0112rem;
        }
        .active{
            background: #1DA1F4;
          }
        .top{
          margin: 0 0.15rem;
          background: #fff;
          padding: 0.1rem;
          border-radius: 0.04rem;
          .order_title{
            font-family: PingFangTC-Regular;
            font-size: 0.16rem;
            color: #333B46;
            letter-spacing: 0.0112rem;
          }
        .place{
          margin-top:0.08rem;
        }
        .status{
          margin-top:0.03rem;
        }
        .status,.place{
        // margin-bottom: 0.13rem;
         span:first-child{
          font-family: PingFangTC-Regular;
          // font-size: 14px;
          color:  #999FAA;
          letter-spacing: 0.0114rem;
        }
        span:last-child{
          font-family: PingFangTC-Regular;
          // font-size: 14px;
          color: #626B77;
          letter-spacing: 0.0114px;
          line-height: 0.2rem;
        }
      }
        }
    .tops{
      .tip{
        display: inline-block;
        width:0.04rem;
        height: 0.15rem;
        margin-right: 0.05rem;
        background: #1DA1F4;
      }
      margin: 0.16rem 0 0.12rem;
      font-family: PingFangTC-Medium;
      font-size: 0.16rem;
      color: #333B46;
      letter-spacing: 0.0112rem;
    }
    .option{
      li{
        background: #FFFFFF;
        border-radius: 0.04rem;
        padding: 0.1rem;
        margin-bottom: 0.15rem;
        .quest{
          padding-left: 0.1rem;
        }
        .li_title{
          font-family: PingFangTC-Regular;
          font-size: 0.16rem;
          color: #333B46;
          letter-spacing: 0.0112rem;
        }
        .check{
          margin-top:0.08rem;
          font-family: PingFangTC-Regular;
          font-size: 0.14rem;
          color: #626B77;
          letter-spacing: 0.0114rem;
          position: relative;
           /deep/ .van-radio__icon{
               position: absolute;
               top: 0.05rem;
            }
           /deep/ .van-checkbox__icon{
              position: absolute;
               top: 0.05rem;
           }
           /deep/ .van-radio__label {
              margin-left: 0.2rem;
          }
           /deep/ .van-checkbox__label{
              margin-left: 0.2rem;
           }
        }
        .check1{
          display: flex;
           margin-top:0.08rem;
          font-family: PingFangTC-Regular;
          font-size: 0.14rem;
          color: #626B77;
          letter-spacing: 0.0114rem;
          span{
            display: inline-block;
            width: auto;
            flex: none;
          }
          input{
            border: none;
            border-bottom: 0.5px solid #D4D9DC;
            width: 100%;
            box-sizing: border-box;
          }
        }
        textarea{
          width: 2.9rem;
          height: 0.4rem;
          border: 0.5px solid;
          // margin-top: 0.07rem;
        }
        .one{
          padding-bottom: 0.07rem;
        }
        .line{
          border: none; 
          border-bottom: 0.5px solid #D4D9DC;
          width: auto;
        }
      }
     
    }
    }
   
    
 
</style>
