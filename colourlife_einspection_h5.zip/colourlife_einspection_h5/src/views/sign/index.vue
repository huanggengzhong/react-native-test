<template>
  <div class="sign">
    <div class="top">
      <div class="time">{{time}}</div>
      <div class="date">{{date}}</div>
      <div class="address"><span>{{address || "网络异常，定位获取失败"}}</span><img :hidden="hidden" @click="refresh" src="./images/icon_shuaxin@2x.png" alt=""></div>
    </div>
    <div class="photo">
      <template v-if="isIos">
        <div class="ios_img" :hidden="!nextBol" >
          <input :disabled="finished"  @change="upaddImg" ref='putsrc' class="upload input_fill" type="file" accept="image/*" capture="camera">
          <img class="upload"  src="./images/icon_shangchuan@2x.png" alt />
           <!-- <van-uploader
            :disabled="!finished"
            :after-read="afterRead"
            v-model="fileList"
            :preview-full-image="false"
            preview-size="1.2rem"
            capture="camera"
            :before-delete="deletes"
            image-fit="cover"
            :max-count="1"
          >
          <img class="upload" ref='putsrc' src="./images/icon_shangchuan@2x.png" alt />
          </van-uploader> -->
        </div>
         <div :hidden="nextBol" class="delll" >
            <img  class="upload" ref='putsrc' :src="fileObj[0]" alt />
            <div class="delbtn" @click="deletes"></div>
        </div>
      </template>
      <template v-else>
        <div :hidden="!nextBol" >
            <img  @click='photos' class="upload"  src="./images/icon_shangchuan@2x.png" alt />
        </div>
         <div :hidden="nextBol" class="delll" >
            <img  class="upload" ref='putsrc' :src="fileObj[0]" alt />
            <div class="delbtn" @click="deletes"></div>
        </div>
      </template>
    
      <p >提示：请上传当前设备的照片</p>
      <!-- <input type="file"  capture="camera"
id="file"  accept="image/*"> -->
      <!-- <canvas id="myCanvas"></canvas> -->
    </div>
    <button class="btn" :class="{ active: !nextBol }" @click="next" :disabled='nextBol'>下一步</button>
  </div>
</template>
<script>
import { upload, nextGeographicLocation} from "@/api";
import {getGeolocation,galleryActivity,showLoading, hideLoading} from '@/common/utils';
import App from '@/common/app-methods'
import Vue from "vue";
import { Uploader,Toast, Dialog, Loading ,Notify} from "vant";
Vue.use(Uploader).use(Toast).use( Dialog).use(Loading).use(Notify);
export default {
  data() {
    return {
      address: "",
      name: '',
      isloading: true,
      finished: true,//拍照
      hidden: false,
      orderList: [],
      nextBol: true,//是否能进行下一步
      show: false,
      fileObj: [],
      fileList: [],
      file_id: '',
      time: '',
      date: '',
      week : ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
      isIos: true
    };
  },
  components: {
    // Statement,
    // AddressSelected,
    // OrderItem
  },
  created() {
    // this.getPjProjectByUserId();
      this.getLocation()
   this.name = this.$route.query.name
    // var timerID = setInterval(this.updateTime(), )
    //  sessionStorage.setItem('address', data.formattedAddress || '')
    this.isIos = /(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent);
     if(sessionStorage.getItem('address')){
       this.address = sessionStorage.getItem('address')
       this.hidden = true
       this.finished = false
     }else{
       Dialog.confirm({
          message: '请先开启GPS！',
          confirmButtonText: '我知道了',
          showCancelButton: false
        }).then(() => {
            // confirm()
        }).catch(() => {
          // on cancel
        });
      // this.getLocation()
       
     }
    setInterval(()=>{
      // console.log('d')
      this.updateTime()
    },1000)
    this.updateTime()
  },
  mounted() {
     this.getLocation()
   
  },

  methods: {
    
    photos(){
      if(!this.finished){
          this.galleryActivity()
      }
    },
    // loding(){
      
    //   // this.isloading = false
    //   return true
    // },
    galleryActivity() {
        let _this = this
        if(this.isIos){
                // this.ios('galleryActivity', { "choiceMode": "1", "photoType": "imagepath" })
        }else{
                    this.android('galleryActivity', JSON.stringify({ "choiceMode": "1", "photoType": "imagepath" }))
                    window.galleryActivityHandler = info => {
                      console.log(JSON.parse(info).type)
                      // _this.showLoading()
                     showLoading()
                      let str = `data:${JSON.parse(info).type};base64,${JSON.parse(info).imagepath}`
                    //  _this.dataURItoBlob(str,JSON.parse(info).name)
                      _this.compressEvent(str,JSON.parse(info).name)
                      // let file = _this.dataURItoBlob(str,JSON.parse(info).name)
                                // console.log(file)
                    }
        }
        
    },
     android(methodsName, ...args) {
          return new Promise((resolve, reject) => {
              try {
                  if (args.length) {
                      resolve(JSON.parse(window.jsObject[methodsName](...args)))
                      return
                  }
                  resolve(JSON.parse(window.jsObject[methodsName]()))
              } catch (error) {
                  reject(error)
              }
          })
      },
    refresh(){
      location.reload()
    },
    getLocation() {
      console.log('h')
    const self = this
    AMap.plugin('AMap.Geolocation', function() {
        var geolocation = new AMap.Geolocation({
            // 是否使用高精度定位，默认：true
            enableHighAccuracy: true,
            // 设置定位超时时间，默认：无穷大
            timeout: 20000,
        })

        geolocation.getCurrentPosition()
        AMap.event.addListener(geolocation, 'complete', onComplete)
        AMap.event.addListener(geolocation, 'error', onError)

        function onComplete(data) {
            console.log('定位成功信息：', data)
            // if (data.location_type != 'html5') {
            //     // Dialog.alert({
            //     //     message: '请先开启GPS！'
            //     // }).then(() => {

            //     // });
            // } else {
                sessionStorage.setItem('address', data.formattedAddress || ''); //当前地址位置信息
                sessionStorage.setItem('longitude', data.position.lng || ''); //经度
                sessionStorage.setItem('latitude', data.position.lat || ''); //维度
                this.address = data.formattedAddress
                this.hidden = true
                this.finished = false
            // }

        }

        function onError(data) {
            // 定位出错
            console.log('定位失败错误：', data)
                // self.getLngLatLocation()
        }
    })
},
    updateTime() {
      var cd = new Date();
      this.time = this.zeroPadding(cd.getHours(), 2) + ':' + this.zeroPadding(cd.getMinutes(), 2);
      this.date = this.zeroPadding(cd.getFullYear(), 4) + '年' + this.zeroPadding(cd.getMonth()+1, 2) + '月' + this.zeroPadding(cd.getDate(), 2) + '日 ' + this.week[cd.getDay()];
    },
    zeroPadding(num, digit) {
      var zero = '';
      for(var i = 0; i < digit; i++) {
        zero += '0';
      }
      return (zero + num).slice(-digit);
    },
    afterRead(files) {
      console.log(files);
       showLoading()
       this.addwatermark(files.content,files.file.name,2)
      // this.addImg(files.file.name);
    },
    upaddImg(e){
    let _this = this
    // let inputDOM = this.$refs.putsrc;
    console.log(e,e.target.files,"ds")
    
    if(e && e.target.files && e.target.files[0]){
      showLoading()
    //   this.addImg(e.target.files[0])
    // }
      let reader = new FileReader();     //html5读文件
      reader.readAsDataURL(e.target.files[0] || e.target.dataTransfer.files[0]); //转BASE64  
      var namef =    e.target.files[0].name  
      reader.onload=function(e) {
        var   imgFile = e.target.result
        _this.compressEvent(imgFile,namef)
       
      }
    }
        // 通过DOM取文件数据
        // this.fil = inputDOM.files;
        // let oldLen=this.imgLen;
        // let len=this.fil.length+oldLen;
    },
    //加水印
    addwatermark(base,name){
      console.log(name)
      var _this = this
      // console.log(base)
       let img = new Image();
       img.src=base;
       img.onload=function(){
            let canvas= document.createElement("canvas");
            let  ctx=canvas.getContext('2d');
            let initSize=img.src.length;
            let width=img.width;
            let height=img.height;
              canvas.width = width;
              canvas.height = height + 100;  // 给canvas 赋值高度
              ctx.save();
              console.log(width,height)
              ctx.fillStyle = "#fff";
              ctx.fillRect(0,0,width,height + 100);  // 绘制图片的背景
              ctx.restore();
              ctx.save();
              ctx.font="bold 20px 微软雅黑";
              ctx.fillStyle = "#000";
              // ctx.restore();
              console.log('2')
              ctx.fillText(_this.name,10,height+75);//绘制截取部分
              ctx.fillText(`${_this.date} ${_this.time}`,10,height+50);//绘制截取部分
              ctx.fillText(_this.address,10,height+25);//绘制截取部分
              console.log('3')
              ctx.drawImage(img, 0, 0, width, height);
              // ctx.fillText(_this.name,10,55);//绘制截取部分
              console.log('4')
              var url = canvas.toDataURL("image/jpeg", 0.5);
              console.log('5')
              // // console.log(url)
              setTimeout(()=>{
                // console.log(url)
              // if(num == 1){
              //   console.log(url)
                  _this.dataURItoBlob(url,name)
                  // console.log(url)
              // }else{
              //   console.log(url)
              //   _this.dataURItoBlob(url,name,2)
              // }
               
              },1000)
       }
      
        
        // console.log( blob+'jkj')
        // this.addImg(files.file);
        
    },
    deletes(file) {
      // console.log(this.fileList, file);
      this.fileObj = [];
      this.nextBol = true;
      // this.isloading = true
      return true
    },
    compressEvent(base,name) {
      console.log(name)
      var _this = this
      // console.log(base)
       let img = new Image();
       img.src=base;
       img.onload=function(){
            let canvas= document.createElement("canvas");
            let  ctx=canvas.getContext('2d');
            let initSize=img.src.length;
            // console.log(initSize)
            let width=img.width;
            let height=img.height;
             canvas.width = width;
              canvas.height = height;  // 给canvas 赋值高度
              ctx.save();
              ctx.drawImage(img, 0, 0, width, height);
              var url = canvas.toDataURL("image/jpeg", 0.5);
              setTimeout(()=>{
                  _this.dataURItoBlob(url,name)
              },1000)
       }
    },
    dataURItoBlob(dataurl,filename) {
      //dataurl是base64格式
      //  console.log(dataurl)
      var arr = dataurl.split(","),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      // return new Blob([u8arr], { type: mime });
      let bold = new Blob([u8arr],{type:mime});
      let file = this.blobToFile(bold,filename)
      // let file = new File([u8arr], filename, {type:mime});
      // console.log(file.name+'aq')
      // if(num == 1){
          this.addImg(file);
      // }else{
      //   this.addImg2(file);
      // }
       
      // return new Blob([u8arr], { type: mime });
    },
    　//转成file
     blobToFile(Blob, fileName) {
        Blob.lastModifiedDate = new Date();
        Blob.name = fileName;
        return Blob;
      },
    addImg(file) {
      //  console.log(event)
      //  let file = document.getElementById("upfile").files[0];//获取文件信息
      //  console.log(file)
      // _this.showLoading()
      var setTIme = setTimeout(function(){
          // const toast1 = Toast("您当前网络较差，请刷新重试");
          Notify({
              message: '您当前网络较差，请刷新重试',
              color: '#fff',
              background: 'rgba(50,50,51,.88)',
              duration: 2000
            });
      },10000)
      upload({ file: file }).then(res => {
        console.log(res);
        if (res.data.code === 0) {
          // this.hideLoading()
          clearTimeout(setTIme)
           hideLoading()
          this.fileObj.push(res.data.content.file_url);
          this.file_id = res.data.content.file_id;
          this.nextBol = false;
          console.log('ds')
        } else {
          // this.isloading = true
           clearTimeout(setTIme)
           hideLoading()
          Toast(res.data.message || '');
        }
      });
    },
    // addImg2(file) {
    //   //  console.log(event)
    //   //  let file = document.getElementById("upfile").files[0];//获取文件信息
    //   //  console.log(file)
    //   // _this.showLoading()
    //   upload({ file: file }).then(res => {
    //     console.log(res);
    //     if (res.data.code === 0) {
    //       hideLoading()
    //       this.fileObj.push(res.data.content);
    //       this.nextBol = false;
          
    //     } else {
    //       hideLoading()
    //       // this.isloading = true
    //       Toast.fail(res.message);
    //     }
    //   });
    // },
    next() {
      console.log(this.fileObj);
      let params = {
        file_id: this.file_id,//图片地址
        task_id: this.$route.query.id,//任务编号
        order_no: this.$route.query.orderId,//订单号
        oa_account: sessionStorage.getItem('oa_account') || '',//发单人
        humanTraNo: sessionStorage.getItem('humanTraNo') || '',//人资单号
        longitude: sessionStorage.getItem('longitude') || '',//作业地点经度
        latitude: sessionStorage.getItem('latitude') || '',//作业地点纬度
        address: sessionStorage.getItem('address') || '',//作业地点
      };
      nextGeographicLocation(params).then(res => {
        if (res.code === 0) {
          this.$router.push({
            path: "/detail",
            query: {
              id: this.$route.query.id
            }
          });
        }else{
          Toast(res.message)
        }
      });
    },
    //调取IOS原生接口
    //cmd代表要调用的功能名称
    invokeNative(cmd) {
      return (document.location = "colour:///" + cmd);
    },

    // ios调用原生接口回调函数
    returnByNativeWithResult(json) {
      var result = JSON.parse(json);
      if (result.code != "0") {
        Toast.fail("定位失败");
      } else {
        this.processResult(result); //处理定位结果
      }
    },

    // 安卓调用原生定位接口回调函数
    LatLngCallBack(res) {
      var result = eval("(" + res + ")");
      if (result.code != "0") {
        Toast.fail("定位失败");
      } else {
        this.processResult(result);
      }
    },

    // 安卓返回结果
    processResult(result) {
      var content = result.content;
      var lng = content.longitude;
      var lat = content.latitude;
      var cpoint = new AMap.LngLat(lng, lat); //中心点坐标

      this.regeocoder(cpoint);
    },

    //根据经纬度解析地址
    regeocoder(cpoint) {
      //逆地理编码
      var _this = this;
      var geocoder = new AMap.Geocoder({
        radius: 500, //范围
        extensions: "all"
      });
      geocoder.getAddress(cpoint, function(status, result) {
        if (status === "complete" && result.info === "OK") {
          
          // _this.geocoder_CallBack(result);
        } else {
          Toast.fail("获取地址信息失败");
        }
      });
    },

    // 逆地理编码回调函数
    geocoder_CallBack(result) {
      var address = result.regeocode.formattedAddress;
      sessionStorage.setItem("address", address || ""); //当前地址位置信息
      console.log(address);
    }
  }
};
</script>
<style lang="scss" scoped>
// @import './style.scss';

.sign {
  padding-bottom: 0.44rem;
  height: 100vh;
  background: #fff;
  box-sizing: border-box;
  .delll{
    position: relative;
    // display: inline-block/;
    .delbtn{
      position: absolute;
      top: -0.08rem;
      right: 1.22rem;
      width: 0.16rem;
      height: 0.16rem;
       background: url(./images/icon_del@2x.png) no-repeat;
      background-size: cover;
    }
  }
  .ios_img{
    position: relative;
  }
  .input_fill{
    position: absolute;
    opacity: 0;
    z-index: 999;
  }
  .btn {
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 0.44rem;
    background: #d4d9dc;
    border: none;
    text-align: center;
    line-height: 0.44rem;
    font-family: PingFangTC-Regular;
    font-size: 0.16rem;
    color: #ffffff;
    letter-spacing: 0.0112rem;
  }
  .active{
  background: #1DA1F4;
}
  .top {
    box-sizing: border-box;
    width: 100%;
    height: 1.8rem;
    background: url(./images/icon_bg@2x.png) no-repeat;
    background-size: cover;
    padding-left: 0.29rem;
    color: #ffffff;
    font-family: PingFangTC-Regular;

    .time {
      padding-top: 0.62rem;
      font-size: 0.3rem;
      letter-spacing: 0.021rem;
      // text-align: center;
    }
    .date {
      font-size: 0.14rem;
      letter-spacing: 0.0098rem;
      padding-bottom: 0.05rem;
      // text-align: center;
    }
    .address {
      padding-left: 0.16rem;
      font-size: 0.12rem;
      letter-spacing: 0.0084rem;
      background: url(./images/icon_dizhi@2x.png) no-repeat left center;
      background-size: 0.11rem 0.13rem;
      img{
        width: 0.16rem;
        height: 0.14rem;
        margin-left: 0.17rem;
      }
    }
  }
  .photo {
    margin-top: 0.9rem;
    text-align: center;
    .upload {
      width: 1.2rem;
      height: 1.2rem;
      font-size: 100%;
    }
    p {
      margin-top: 0.17rem;
      font-family: PingFangTC-Regular;
      font-size: 0.12rem;
      color: #999faa;
      letter-spacing: 0.0084rem;
      text-align: center;
    }
  }
}
</style>
