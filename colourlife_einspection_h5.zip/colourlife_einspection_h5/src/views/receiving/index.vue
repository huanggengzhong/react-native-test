<template>
  <div class="receiving">
    <div class="order_receiving">
      <ul>
        <li>
          <div class="list_box">
            <div class="titles">
              <p>{{detail.ins_name || ''}}</p>
            <!-- <template v-if="detail.status == 1"> -->
                <span class="status">{{arr[detail.status]}}</span>
            <!-- </template> -->
            </div>
            <div>
              <p class="price">¥{{detail.price || 0}}</p>
              <template v-if="detail.cycle_time != 1">
                  <p class="time">
                    <span>服务开始时间：</span><span>{{detail.ins_date}} {{detail.start_time}}</span>
                  </p>
                  <p class="time">
                    <span>服务结束时间：</span><span>{{detail.ins_date}} {{detail.end_time}}</span>
                  </p>
              </template>
              <template v-else>
                  <p class="time">
                    <span>服务开始时间：</span><span>{{detail.start_date}} {{detail.start_time}}</span>
                  </p>
                  <p class="time">
                    <span>服务结束时间：</span><span>{{detail.end_date}} {{detail.end_time}}</span>
                  </p>
              </template>
            </div>
          </div>
        </li>
        <li>
          <div class="list_box">
            <div class="title"><span>订单编号</span></div>
            <div class="clearfix">
              <p class="order_code "><span class="code">{{detail.order_no || ''}}</span>
               <span
              @click="doCopy(detail.order_no || '')"
              class="copy">复制</span>
              </p>
             
            </div>
          </div>
        </li>
        <li>
          <div class="list_box">
            <div class="title"><span>订单任务信息</span></div>
            <div class="message_list">
              <p class="message"  v-for="(item,index) in task" :key="index" >
                <span>{{index+1}}.{{item.task}}巡检：</span><span>{{item.detail}}</span>
              </p>
              <!-- <p class="message">
                <span>2、大堂卫生巡检：</span><span>日常卫生是否符合要求</span>
              </p>
              <p class="message">
                <span>3、1#消防栓巡检：</span><span>查看是否正常</span>
              </p> -->
            </div>
          </div>
        </li>
         <li>
          <div class="list_box">
            <div class="title"><span>发单人信息</span></div>
            <div class="user_info">
              <div class="image">
                <img src="./images/icon_tx@2x.png" alt="">
              </div>
              <div class="user_name">
                <p>{{name || ''}}</p>
                <p>{{detail.com_name || ''}}</p>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <template v-if="detail.status == 1">
        <button class="btn" @click="getOrder">接单</button>
    </template>
    <template v-else-if="detail.status == 2">
      <div class="foot">
      <button class="btn_left" @click="startServer">开始服务</button>
      <button class="btn_right" @click="cancelOrder">取消接单</button>
      </div>
    </template>
    <template v-else-if="detail.status == 3">
        <button class="btn" @click="startServer">继续服务</button>
    </template>
    <template v-else-if="detail.status == 4">
      <button class="btn" >已完成</button>
    </template>
  </div>
</template>
<script>
import {getOrderDetail,getOrCancel,getOrderPage} from '@/api';
import {getUrlParam,compareDate2} from '@/common/utils';
import Vue from 'vue';
import { Notify,Toast,Dialog  } from 'vant';
import VueClipboard from 'vue-clipboard2';
Vue.use(VueClipboard);
Vue.use(Notify).use(Toast).use(Dialog);
export default {
  data () {
    return {
      detail: '',
      name:'',
      task: [],
      oa_account: '',
      getName:'',
      parameter: '',
      arr:['','待接单','已接单','执行中','已完成','已评价','已分账','已冻结','待审核','审核不通过','已关闭'] //用于状态呈文字展示
      // orderCode: '',
    };
  },
  // components: {
  //   // Statement,
  //   // AddressSelected,
  //   // OrderItem
  // },
  created () {
   
    let parms = getUrlParam()
    this.parameter = parms
    console.log(parms)
    // let order = sessionStorage.getItem('humanTraNo',parms.orderno)
    this.getOrderPage(parms.orderno || this.$route.query.humanTraNo)
    if(parms.orderno){
      sessionStorage.setItem('humanTraNo',parms.orderno)
    }
    // this.getName = parms.provider_name
    // console.log(parms.provider_name) 
  },
  mounted(){//这里必须是mouted钩子
  
  },
  methods: {
  GetRequest() {
    // let num = document.location.href.indexOf("?");
    // let url = document.location.href.slice(num) ; //获取url中"?"符后的字串
    // let theRequest = {};
    // if (url.indexOf("?") !== -1) {
    //     let str = url.substr(1);
    //     let strs = str.split("&");
    //     for ( let i = 0; i < strs.length; i++) {
    //         theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
    //     }
    // }
    // return theRequest;
  },
  getOrderPage(parms){
    getOrderPage({orderno:parms}).then(res=>{
        console.log(res)
        if(res.code === 0){
           this.name = res.content.user.name
           this.oa_account = res.content.user.oa_account
           sessionStorage.setItem('oa_account',res.content.user.oa_account)
           this.detail = res.content.data.content[0]
           this.task =  JSON.parse(res.content.data.content[0].inspection_comment)
        }else{
          Toast(res.message || "请求错误")
        }
    })
  },
  getOrder(){
        let params = {
          order_no: this.detail.order_no,
          status:2,
          oa_account:this.oa_account,
          operator:this.parameter.provider_name,
          humanTraNo: this.detail.humantra_no,
          moblie: this.parameter.tel
        }
    getOrCancel(params).then(res=>{
          if(res.code === 0){
            Toast('接单成功')
            this.getOrderPage(this.detail.humantra_no)
          }else{
            Toast(res.message || '接单失败')
          }
    })
       
  },
   cancelOrder(){
     let params = {
          order_no: this.detail.order_no,
          status:1,
          oa_account:this.oa_account,
          operator:this.parameter.provider_name,
          humanTraNo: this.detail.humantra_no,
          moblie: this.parameter.tel
        }
        Dialog.confirm({
        // title: '标题',
        message: '取消订单号，订单将退回人力资源池，是否要继续？'
      }).then(() => {
          getOrCancel(params).then(res=>{
              if(res.code === 0){
                this.getOrderPage(this.detail.humantra_no)
              }else{
                Toast(res.message || '取消接单失败')
              }
          })
      }).catch(() => {
        // on cancel
      });
   
  },
    startServer(){
      // let bol = false
      if(this.detail.cycle_time != 1){
          let d1 = `${this.detail.ins_date} ${this.detail.start_time}`
          // let bol = compareDate2(d1)
          // console.log(Date.parse(new Date()) <= new Date(Date.parse(d1.replace(/-/g, '/'))))
          // console.log(new Date(Date.parse(d1.replace(/-/g, '/'))))
          if(Date.parse(new Date()) >= new Date(Date.parse(d1.replace(/-/g, '/')))){
            this.$router.push({
                  path: "/home",
                  query: {
                    id: this.detail.order_no,
                    name: this.parameter.provider_name,
                  }
                });
            }else{
              // Notify("还未到服务时间")
              Toast('还未到服务时间')
            }
      }else{
          let d1 = `${this.detail.start_date} ${this.detail.start_time}`
          // console.log(Date.parse(new Date()) <= new Date(Date.parse(d1.replace(/-/g, '/'))))
          // console.log(new Date(Date.parse(d1.replace(/-/g, '/'))))
          if(Date.parse(new Date()) >= new Date(Date.parse(d1.replace(/-/g, '/')))){
            this.$router.push({
                  path: "/home",
                  query: {
                    id: this.detail.order_no,
                    name: this.parameter.provider_name,
                  }
                });
            }else{
              // Notify("还未到服务时间")
              Toast('还未到服务时间')
            }   
      }
  },
  doCopy(val) {
        Toast.setDefaultOptions({
          position: 'top',
          duration: 1000
        })
        this.$copyText(val).then(function (e) {
          Toast('复制成功')
          // Notify({
          //   type: 'primary',
          //   message: '复制成功',
          //   // color: '#1DA1F4',
          //   duration: 1000
          // });
        }, function (e) {
          Toast('您的手机不支持一键复制，请手动复制')
          // Notify({
          //   type: 'primary',
          //   message: '您的手机不支持一键复制，请手动复制',
          //   // color: '#1DA1F4',
          //   duration: 1000
          // });
        })
      }
  }
};
</script>
<style lang="scss" scoped>
// @import './style.scss';
    .receiving{
      .order_receiving{
       padding: 0.12rem 0.15rem 0.44rem;
        ul li{
          background: #fff;
          border-radius: 0.04rem;
          margin-bottom: 0.12rem;
          padding-bottom: 0.12rem;
          .list_box{
            margin-left: 0.1rem;
            .titles{
              position: relative;
               p{
                font-family: PingFangTC-Regular;
                font-size: 0.16rem;
                width: 2.75rem;
                padding: 0.09rem 0;
                display: inline-block;
                color: #333B46;
                letter-spacing: 0.0112rem;
              }
              .status{
                  position: absolute;
                  top: 50%;
                  right: 0;
                  margin-top: -0.11rem;
                  font-family: PingFangTC-Regular;
                  font-size: 0.14rem;
                  color: #EF7E33;
                  letter-spacing: 0.0098rem;
                  float: right;
                  margin-right: 0.13rem;
                }
            }
            .title{
              height: 0.42rem;
              line-height: 0.42rem;
              border-bottom: 0.05px solid #D4D9DC;
              span:first-child{
                font-family: PingFangTC-Regular;
                font-size: 0.16rem;
                color: #333B46;
                letter-spacing: 0.0112rem;
              }
              
            }
            .price{
              font-family: PingFangTC-Medium;
              font-size: 0.16rem;
              color: #F7667C;
              letter-spacing: 0.0131rem;
              padding-top: 0.1rem;
            }
            .time,.message{
              padding-top: 0.02rem;
              font-family: PingFangTC-Regular;
              font-size: 0.14rem;
              letter-spacing: 0.0114rem;
              span:first-child{
                color: #999FAA;
              }
              span:last-child{
                color: #626B77;
              }
            }
            .order_code{
              font-family: PingFangTC-Regular;
              font-size: 0.14rem;
              letter-spacing: 0.0123rem;
              padding-top: 0.12rem;
              .code{
                color: #626B77;
              }
              
            }
            .copy{
                color: #1DA1F4;
                float: right;
                margin-right: 0.13rem;
              }
            .message_list{
              padding-top: 0.12rem;
            }
            .user_info{
              padding: 0.15rem 0 0.12rem;
              .image{
              display: inline-block;
               width: 0.45rem;
                height: 0.45rem;
                background: #626B77;
                border-radius: 50%;
                float: left;
              img{
                width: 100%;
                height: 100%;
                
              }
            }
            .user_name{
              display: inline-block;
              padding-left:0.1rem;
              width: 2.7rem;
              p:first-child{
                font-family: PingFangTC-Regular;
                font-size: 0.14rem;
                color: #626B77;
                letter-spacing: 0.0112rem;
              }
              p:last-child{
                font-family: PingFangTC-Regular;
                font-size: 0.12rem;
                color: #999FAA;
                letter-spacing: 0.0084rem;
              }
            }
            }
           
          }
        }
      }
      .btn{
          position: fixed;
          bottom: 0;
          width: 100%;
          height: 0.44rem;
          background: #1DA1F4;
          border: none;
          text-align: center;
          line-height: 0.44rem;
          font-family: PingFangTC-Regular;
          font-size: 0.16rem;
          color: #FFFFFF;
          letter-spacing: 0.0112rem;
        }
        .foot{
          position: fixed;
          bottom: 0;
          width: 100%;
          height: 0.44rem;
          .btn_left{
            display: inline-block;
            width: 50%;
            height: 0.44rem;
            background: #1DA1F4;
            border: none;
            text-align: center;
            line-height: 0.44rem;
            font-family: PingFangTC-Regular;
            font-size: 0.16rem;
            color: #FFFFFF;
            letter-spacing: 0.0112rem;
          }
          .btn_right{
            display: inline-block;
            width: 50%;
            height: 0.44rem;
            background: #F7667C;
            border: none;
            text-align: center;
            line-height: 0.44rem;
            font-family: PingFangTC-Regular;
            font-size: 0.16rem;
            color: #FFFFFF;
            letter-spacing: 0.0112rem;
          }
        }
     
    }
   
    
 
</style>
